import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        LoginSystem system = new LoginSystem();
        system.start();  // Start the login and registration loop
    }
}