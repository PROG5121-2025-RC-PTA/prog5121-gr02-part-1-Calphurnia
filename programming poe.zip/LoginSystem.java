import java.util.Scanner;

public class LoginSystem {

   private static String savedUsername = "";
    private static String savedPassword = "";
    private static Scanner scanner = new Scanner (System.in);
            

    public void start() {
        int choice;
    
        do {
            System.out.println("\n=== Welcome to the User System ===");
            System.out.println("1.Register");
            System.out.println("2.Login");
            System.out.println("3.Exit");
            System.out.print("Enter your choice:");
            choice = Integer.parseInt(scanner.nextLine()); // Consume the leftover newline
        
            switch(choice){ 
                case 1: 
                    registerUser();
                    break;
                case 2:
                    loginUser();
                    break;
                case 3:
                    System.out.println("Exiting program. Goodbye!");
                    break;
                default:
                    System.out.println("invalid choice! Please select 1;2;or3.");
            }
        } while (choice != 3);
    }
       private void registerUser() {
          if(!savedUsername.isEmpty()) {
            System.out.println("A user is already registered. Please login."); 
          }
        System.out.print("Enter a username:");
        savedUsername = scanner.nextLine();
        
        System.out.print("Enter a password:");
        savedPassword = scanner.nextLine();
        
        System.out.println("Registration successful!");
    }
       private void loginUser(){
        if (savedUsername.isEmpty()) {
             System.out.println("No registered user found. Please register first.");
            return;
        }

        System.out.print("Enter your username:");
        String username = scanner.nextLine();
        System.out.print("Enter password:");
        String password = scanner.nextLine();

        if (username.equals(savedUsername) && password.equals(savedPassword)) {
            System.out.println("Login successful! Welcome, " + username + "!");
        } else {
            System.out.println("Login failed! incorrect username or password.");
        }
      }
}