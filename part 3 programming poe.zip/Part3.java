import java.util.*;
import javax.swing.*;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class LoginSystem {

    private static String savedUsername = "";
    private static String savedPassword = "";
    private static final Scanner scanner = new Scanner(System.in);
    private static JSONArray messages = new JSONArray();

    // Arrays for parallel tracking
    private static final ArrayList<JSONObject> sentMessagesList = new ArrayList<>();
    private static final ArrayList<String> disregardedMessages = new ArrayList<>();
    private static final ArrayList<String> storedMessages = new ArrayList<>();
    private static final ArrayList<String> messageHashes = new ArrayList<>();
    private static final ArrayList<String> messageIDs = new ArrayList<>();

    public void start() {
        SwingUtilities.invokeLater(() -> {
            String[] options = {"Register", "Login", "Send Message", "Message Report", "Exit"};
            boolean running = true;

            while (running) {
                int choice = JOptionPane.showOptionDialog(null, "Choose an option", "User System Menu",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                        null, options, options[0]);

                switch (choice) {
                    case 0 -> registerUser();
                    case 1 -> loginUser();
                    case 2 -> sendMessage();
                    case 3 -> showReportMenu();
                    case 4 -> {
                        JOptionPane.showMessageDialog(null, "Exiting program. Goodbye!");
                        running = false;
                    }
                    default -> JOptionPane.showMessageDialog(null, "Invalid option selected.");
                }
            }
        });
    }

    private void registerUser() {
        if (!savedUsername.isEmpty()) {
            JOptionPane.showMessageDialog(null, "A user is already registered. Please login.");
            return;
        }
        savedUsername = JOptionPane.showInputDialog("Enter a username:");
        savedPassword = JOptionPane.showInputDialog("Enter a password:");
        JOptionPane.showMessageDialog(null, "Registration successful!");
    }

    private void loginUser() {
        if (savedUsername.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No registered user found. Please register first.");
            return;
        }
        String username = JOptionPane.showInputDialog("Enter your username:");
        String password = JOptionPane.showInputDialog("Enter your password:");
        if (username.equals(savedUsername) && password.equals(savedPassword)) {
            JOptionPane.showMessageDialog(null, "Login successful! Welcome, " + username + "!");
        } else {
            JOptionPane.showMessageDialog(null, "Login failed! Incorrect username or password.");
        }
    }

    private void sendMessage() {
        MessageHandler msg = new MessageHandler();
        msg.send();
    }

    // Handles message input and storage
    private class MessageHandler {
        public void send() {
            int messageCount = 0;
            try {
                messageCount = Integer.parseInt(
                        JOptionPane.showInputDialog("How many messages would you like to send?")
                );
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid number.");
                return;
            }

            for (int i = 1; i <= messageCount; i++) {
                String recipient = JOptionPane.showInputDialog("Enter recipient username:");
                String content = JOptionPane.showInputDialog("Enter message content:");
                String flag = JOptionPane.showInputDialog("Enter flag (Sent / Stored / Disregard):");

                String messageId = "MSG" + recipient.substring(0, 2).toUpperCase() + i;
                String messageHash = (content + recipient + i).hashCode() + "";

                JSONObject message = new JSONObject();
                message.put("recipient", recipient);
                message.put("content", content);
                message.put("messageId", messageId);
                message.put("hash", messageHash);
                message.put("flag", flag);

                messages.add(message);

                // Classify into arrays
                switch (flag.toLowerCase()) {
                    case "sent" -> sentMessagesList.add(message);
                    case "stored" -> storedMessages.add(content);
                    case "disregard" -> disregardedMessages.add(content);
                }

                messageIDs.add(messageId);
                messageHashes.add(messageHash);

                JOptionPane.showMessageDialog(null,
                        "Message Sent!\nID: " + messageId + "\nHash: " + messageHash);
            }

            saveMessagesToJSON();
        }

        private void saveMessagesToJSON() {
            try (FileWriter file = new FileWriter("messages.json")) {
                file.write(messages.toJSONString());
                file.flush();
                JOptionPane.showMessageDialog(null, "Messages saved to messages.json");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error saving messages: " + e.getMessage());
            }
        }
    }

    private void showReportMenu() {
        String[] options = {
                "Display sender & recipient",
                "Longest message",
                "Search by ID",
                "Search by recipient",
                "Delete by hash",
                "Full report",
                "Load from JSON",
                "Back"
        };
        boolean back = false;
        while (!back) {
            int option = JOptionPane.showOptionDialog(null, "Choose report option:", "Report Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (option) {
                case 0 -> displaySenderAndRecipient();
                case 1 -> displayLongestMessage();
                case 2 -> searchMessageByID();
                case 3 -> searchMessagesByRecipient();
                case 4 -> deleteMessageByHash();
                case 5 -> displayFullReport();
                case 6 -> loadMessagesFromJSON();
                case 7 -> back = true;
                default -> JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }

    private void displaySenderAndRecipient() {
        StringBuilder output = new StringBuilder();
        for (JSONObject msg : sentMessagesList) {
            output.append("Recipient: ").append(msg.get("recipient")).append("\n");
        }
        JOptionPane.showMessageDialog(null, output.toString());
    }

    private void displayLongestMessage() {
        String longest = "";
        for (JSONObject msg : sentMessagesList) {
            String content = (String) msg.get("content");
            if (content.length() > longest.length()) {
                longest = content;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest Message: " + longest);
    }

    private void searchMessageByID() {
        String inputId = JOptionPane.showInputDialog("Enter Message ID:");
        for (JSONObject msg : sentMessagesList) {
            if (msg.get("messageId").equals(inputId)) {
                JOptionPane.showMessageDialog(null,
                        "Recipient: " + msg.get("recipient") +
                        "\nMessage: " + msg.get("content"));
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    private void searchMessagesByRecipient() {
        String input = JOptionPane.showInputDialog("Enter recipient number:");
        StringBuilder result = new StringBuilder();
        for (JSONObject msg : sentMessagesList) {
            if (msg.get("recipient").equals(input)) {
                result.append("Message: ").append(msg.get("content")).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, result.length() > 0 ? result.toString() : "No messages found.");
    }

    private void deleteMessageByHash() {
        String input = JOptionPane.showInputDialog("Enter hash to delete:");
        Iterator<JSONObject> it = sentMessagesList.iterator();
        while (it.hasNext()) {
            JSONObject msg = it.next();
            if (msg.get("hash").equals(input)) {
                JOptionPane.showMessageDialog(null,
                        "Message \"" + msg.get("content") + "\" successfully deleted.");
                it.remove();
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Hash not found.");
    }

    private void displayFullReport() {
        StringBuilder report = new StringBuilder();
        for (JSONObject msg : sentMessagesList) {
            report.append("Recipient: ").append(msg.get("recipient")).append("\n")
                  .append("Message: ").append(msg.get("content")).append("\n")
                  .append("ID: ").append(msg.get("messageId")).append("\n")
                  .append("Hash: ").append(msg.get("hash")).append("\n------\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }

    private void loadMessagesFromJSON() {
        try {
            JSONParser parser = new JSONParser();
            JSONArray jsonMessages = (JSONArray) parser.parse(new FileReader("messages.json"));

            sentMessagesList.clear();
            messageIDs.clear();
            messageHashes.clear();

            for (Object obj : jsonMessages) {
                JSONObject msg = (JSONObject) obj;
                sentMessagesList.add(msg);
                messageIDs.add((String) msg.get("messageId"));
                messageHashes.add((String) msg.get("hash"));

                String flag = (String) msg.get("flag");
                if (flag != null) {
                    switch (flag.toLowerCase()) {
                        case "disregard" -> disregardedMessages.add((String) msg.get("content"));
                        case "stored" -> storedMessages.add((String) msg.get("content"));
                    }
                }
            }
            JOptionPane.showMessageDialog(null, "Messages loaded from messages.json");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Failed to load messages: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new LoginSystem().start();
    }
}
