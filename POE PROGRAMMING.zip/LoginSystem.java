import java.util.Scanner;
import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class LoginSystem {

    private static String savedUsername = "";
    private static String savedPassword = "";
    private static final Scanner scanner = new Scanner(System.in);
    private static JSONArray messages = new JSONArray();

    public void start() {
        int choice;

        do {
            System.out.println("\n=== Welcome to the User System ===");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Send Message");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    registerUser();
                    break;
                case 2:
                    loginUser();
                    break;
                case 3:
                    sendMessage();
                    break;
                case 4:
                    System.out.println("Exiting program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice! Please select 1-4.");
            }
        } while (choice != 4);
    }

    private void registerUser() {
        if (!savedUsername.isEmpty()) {
            System.out.println("A user is already registered. Please login.");
            return;
        }
        System.out.print("Enter a username: ");
        savedUsername = scanner.nextLine();

        System.out.print("Enter a password: ");
        savedPassword = scanner.nextLine();

        System.out.println("Registration successful!");
    }

    private void loginUser() {
        if (savedUsername.isEmpty()) {
            System.out.println("No registered user found. Please register first.");
            return;
        }

        System.out.print("Enter your username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (username.equals(savedUsername) && password.equals(savedPassword)) {
            System.out.println("Login successful! Welcome, " + username + "!");
        } else {
            System.out.println("Login failed! Incorrect username or password.");
        }
    }

    private void sendMessage() {
        MessageHandler msg = new MessageHandler();  // Create inner class instance
        msg.send();  // Call method
    }

    // 🟡 PRIVATE INNER CLASS FOR MESSAGING
    private class MessageHandler {
        public void send() {
            int messageCount = 0;
            try {
                messageCount = Integer.parseInt(
                    JOptionPane.showInputDialog("How many messages would you like to send?")
                );
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid number.");
                return;
            }

            for (int i = 1; i <= messageCount; i++) {
                String recipient = JOptionPane.showInputDialog("Enter recipient username:");
                String content = JOptionPane.showInputDialog("Enter message content:");

                String messageId = "MSG" + recipient.substring(0, 2).toUpperCase() + i;
                String messageHash = (content + recipient + i).hashCode() + "";

                JSONObject message = new JSONObject();
                message.put("recipient", recipient);
                message.put("content", content);
                message.put("messageId", messageId);
                message.put("hash", messageHash);

                messages.add(message);

                JOptionPane.showMessageDialog(null,
                        "Message Sent!\nID: " + messageId + "\nHash: " + messageHash
                );
            }

            saveMessagesToJSON();
        }

        private void saveMessagesToJSON() {
            try (FileWriter file = new FileWriter("messages.json")) {
                file.write(messages.toJSONString());
                file.flush();
                JOptionPane.showMessageDialog(null, "Messages saved to messages.json");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error saving messages: " + e.getMessage());
            }
        }
    }
}